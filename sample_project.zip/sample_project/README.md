# 📝 Task Manager — Sample Flask Project

A simple Task Manager web app built with **Python (Flask)** and **HTML/CSS/JS**.

## Project Structure

```
sample_project/
├── app.py                  # Flask application
├── requirements.txt        # Python dependencies
├── templates/
│   └── index.html          # Main HTML page (Jinja2 template)
└── static/
    ├── css/
    │   └── style.css       # Stylesheet
    └── js/
        └── main.js         # Frontend JavaScript
```

## Getting Started

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Open in browser
Visit [http://localhost:5000](http://localhost:5000)

## Features

- View a list of tasks
- Add new tasks via input field or pressing Enter
- Toggle tasks between ⏳ pending and ✅ done
- REST API endpoints (`GET`, `POST`, `PATCH /api/tasks`)
